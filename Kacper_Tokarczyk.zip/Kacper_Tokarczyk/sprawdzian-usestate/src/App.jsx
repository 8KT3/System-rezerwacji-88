import { useState } from 'react'
import './App.css'

function App() {
  const [wlaczony, setWlaczony] = useState(false)
  const [operacje, setOperacje] = useState(0);
  const [pokazPomoc, setPokazPomoc] = useState(false);
  const [odkryjKod, setOdkryjKod] = useState(false);
  const [srodowisko, setSrodowisko] = useState('');

  const [domena, setDomena] = useState("");
  const [uzytkownik, setUzytkownik] = useState("");
  const [autoKlucz, setAutoKlucz] = useState(false);
  const [klucz, setKlucz] = useState("");
  const [podsumowanie, setPodsumowanie] = useState(null);
  
  const [wpisy, setWpisy] = useState([]);
  const [komunikatBledu, setKomunikatBledu] = useState("");

  function generujToken() {
    const znaki = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$&@!";
    let wynik = "";
    for (let i = 0; i < 16; i++) {
      const losowyIndeks = Math.floor(Math.random() * znaki.length);
      wynik += znaki[losowyIndeks];
    }
    setKlucz(wynik);
  }

  function obslugaFormularza(e) {
    e.preventDefault();

    const czystaDomena = domena.trim();
    const czystyUzytkownik = uzytkownik.trim();

    if (czystaDomena === "" || czystyUzytkownik === "") {
      setKomunikatBledu("Uzupełnij poprawnie pola Domena serwisu oraz Użytkownik!");
      return;
    }

    setKomunikatBledu("");

    setPodsumowanie({
      domena: czystaDomena,
      uzytkownik: czystyUzytkownik,
      autoKlucz,
      klucz
    });

    const nowyWpis = {
      id: Date.now(),
      domena: czystaDomena,
      uzytkownik: czystyUzytkownik,
      klucz: autoKlucz ? "[SYSTEMOWY]" : klucz
    };

    setWpisy((prev) => [...prev, nowyWpis]);
  }



  return (
    <>
      <section className="zadanie">
        <h1>Zadanie 1</h1>
        <button className="btn btn-dark" onClick={() => setWlaczony(!wlaczony)}>Zmień tryb</button>
        <p className="mt-2">Tryb pracy: {wlaczony && ("Włączony")} {!wlaczony && ("Wyłączony")}</p>
      </section>

      <section className="zadanie">
        <h1>Zadanie 2</h1>
        <button className="btn btn-primary" onClick={() => setOperacje(operacje + 1)} disabled={operacje >= 7}>+1</button>
        
        <h3>Wartość licznika: {operacje}</h3>

          {operacje >= 7 && (
            <button className="btn btn-danger ms-3" onClick={() => setOperacje(0)}>Zeruj</button>
        )}
      </section>

      <section className="zadanie mb-4">
        <h1>Zadanie 3</h1>

        <button className="btn btn-warning" onClick={() => setPokazPomoc(!pokazPomoc)}>
          {pokazPomoc ? "Zwiń pomoc" : "Rozwiń pomoc"}
        </button>

        {pokazPomoc && (
          <p className="alert alert-secondary mt-3">
            Wskazówka: Zmiana stanu wywołuje ponowne renderowanie komponentu.
          </p>
        )}
      </section>

      <section className="zadanie mb-4">
        <h1>Zadanie 4</h1>

        <input
          type={odkryjKod ? "text" : "password"}
          className="form-control mb-3"
          placeholder="Wpisz kod dostępu"
        />

        <button
          type="button"
          className="btn btn-outline-secondary"
          onClick={() => setOdkryjKod(!odkryjKod)}
        >
          {odkryjKod ? "Maskuj" : "Odkryj"}
        </button>
      </section>

      <section className="zadanie mb-4">
        <h1>Zadanie 5</h1>

        <button className="btn btn-outline-info me-2"  onClick={() => setSrodowisko('DEV')}>
          DEV
        </button>

        <button 
          className="btn btn-outline-info me-2" 
          onClick={() => setSrodowisko('TEST')}
        >
          TEST
        </button>

        <button 
          className="btn btn-outline-info" 
          onClick={() => setSrodowisko('PROD')}
        >
          PROD
        </button>

        <p className="mt-3">
          Aktywny profil: <strong className="text-success">{srodowisko || "nie wybrano"}</strong>
        </p>
      </section>

      <section className="zadanie mb-4">
        <div className="container mt-4" style={{ maxWidth: "600px" }}>
          <h1>Zadanie 6</h1>
          <h1>Panel rejestracji usług – wykonał 27</h1>

          <form onSubmit={obslugaFormularza}>
            <div className="mb-3">
              <label htmlFor="domena" className="form-label">Domena serwisu:</label>
              <input
                type="text"
                className="form-control"
                id="domena"
                placeholder="np. ://example.com"
                value={domena}
                onChange={(e) => setDomena(e.target.value)}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="uzytkownik" className="form-label">Użytkownik:</label>
              <input
                type="text"
                className="form-control"
                id="uzytkownik"
                placeholder="Identyfikator użytkownika"
                value={uzytkownik}
                onChange={(e) => setUzytkownik(e.target.value)}
              />
            </div>

            <div className="form-check mb-3">
              <input
                type="checkbox"
                className="form-check-input"
                id="autoKlucz"
                checked={autoKlucz}
                onChange={(e) => setAutoKlucz(e.target.checked)}
              />
              <label className="form-check-label" htmlFor="autoKlucz">
                Użyj klucza systemowego
              </label>
            </div>

            <div className="mb-3">
              <label htmlFor="klucz" className="form-label">Klucz API:</label>
              <input
                type="password"
                className="form-control"
                id="klucz"
                placeholder="Wpisz klucz"
                value={klucz}
                onChange={(e) => setKlucz(e.target.value)}
                disabled={autoKlucz}
              />
            </div>

            <button type="submit" className="btn btn-success">
              Zatwierdź dane
            </button>
          </form>

          {podsumowanie && (
            <div className="mt-4 border-top pt-3">
              <p className="p-2">Domena: {podsumowanie.domena}</p>
              <p className="p-2 lead text-success">Użytkownik: {podsumowanie.uzytkownik}</p>
              <p className="p-2">
                Klucz API: {podsumowanie.autoKlucz ? "systemowy" : podsumowanie.klucz}
              </p>
            </div>
          )}
        </div>
      </section>


<section className="zadanie mb-4">
  <div className="container mt-4" style={{ maxWidth: "600px" }}>
    <h1>Panel rejestracji usług – wykonał XX</h1>

    <form onSubmit={obslugaFormularza}>
      <div className="mb-3">
        <label htmlFor="domena" className="form-label">Domena serwisu:</label>
        <input
          type="text"
          className="form-control"
          id="domena"
          placeholder="np. ://example.com"
          value={domena}
          onChange={(e) => setDomena(e.target.value)}
        />
      </div>

      <div className="mb-3">
        <label htmlFor="uzytkownik" className="form-label">Użytkownik:</label>
        <input
          type="text"
          className="form-control"
          id="uzytkownik"
          placeholder="Identyfikator użytkownika"
          value={uzytkownik}
          onChange={(e) => setUzytkownik(e.target.value)}
        />
      </div>

      <div className="form-check mb-3">
        <input
          type="checkbox"
          className="form-check-input"
          id="autoKlucz"
          checked={autoKlucz}
          onChange={(e) => setAutoKlucz(e.target.checked)}
        />
        <label className="form-check-label" htmlFor="autoKlucz">
          Użyj klucza systemowego
        </label>
      </div>

      <div className="mb-3">
        <label htmlFor="klucz" className="form-label">Klucz API:</label>
        <div className="d-flex gap-2">
          <input
            type="password"
            className="form-control"
            id="klucz"
            placeholder="Wpisz klucz"
            value={klucz}
            onChange={(e) => setKlucz(e.target.value)}
            disabled={autoKlucz}
          />
          <button
            type="button"
            className="btn btn-outline-primary"
            onClick={generujToken}
            disabled={autoKlucz}
          >
            Generuj klucz
          </button>
        </div>
      </div>

      <button type="submit" className="btn btn-success">
        Zatwierdź dane
      </button>

      {komunikatBledu && (
        <div className="alert alert-danger py-1 mt-2">
          {komunikatBledu}
        </div>
      )}
    </form>

    {podsumowanie && (
      <div className="mt-4 border-top pt-3">
        <p className="p-2">Domena: {podsumowanie.domena}</p>
        <p className="p-2 lead text-success">Użytkownik: {podsumowanie.uzytkownik}</p>
        <p className="p-2">
          Klucz API: {podsumowanie.autoKlucz ? "systemowy" : podsumowanie.klucz}
        </p>
      </div>
    )}

    {wpisy.length > 0 && (
      <div className="mt-4 border-top pt-3">
        <h4>Zapisane wpisy:</h4>
        <ul className="list-group">
          {wpisy.map((item) => (
            <li key={item.id} className="list-group-item">
              <strong>{item.domena}</strong> | Użytkownik: {item.uzytkownik} | Klucz: {item.klucz}
            </li>
          ))}
        </ul>

        <button
          type="button"
          className="btn btn-outline-danger btn-sm mt-3"
          onClick={() => setWpisy([])}
        >
          Wyczyść listę
        </button>
      </div>
    )}
  </div>
</section>

    </>
  )
}

export default App
